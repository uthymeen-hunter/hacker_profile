Hacker Profile - Ready to use
----------------------------
Files included:
- index.html
- style.css
- script.js
- images/myphoto.jpg (your profile picture)
- images/hacker-bg.jpg (background)

How to use (Localhost - XAMPP):
1. Extract this folder into C:\xampp\htdocs\
2. Start Apache in XAMPP control panel.
3. Open http://localhost/hacker_profile_complete in your browser.

How to use (GitHub Pages):
1. Create a new repo on GitHub.
2. Upload all files at the repository root.
3. Enable GitHub Pages (Branch: main, Folder: / (root)).
4. Visit https://your-username.github.io/your-repo-name/

To replace the profile photo, overwrite images/myphoto.jpg with another image (same name).
